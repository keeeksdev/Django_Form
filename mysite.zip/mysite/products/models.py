from django.db import models


class Owner(models.Model):
    name = models.CharField(max_length=2000, null=True, blank=True, default=None)
    surname = models.CharField(max_length=2000, null=True, blank=True, default=None)
    post_code = models.CharField(max_length=2000, null=True, blank=True, default=None)
    
    def __str__(self):
        return self.name +" " + self.surname + " " + self.post_code
        
        
class Product(models.Model):
    name = models.CharField(max_length=2000, null=True, blank=True, default=None)
    description = models.TextField(max_length=20000, null=True, blank=True, default=None)
    price = models.DecimalField(max_digits=5, decimal_places=2,default=0.0, null=True, blank=True)
    owner = models.ManyToManyField(Owner)
    def __str__(self):
        return self.name +" " + self.description + " " + str(self.price) + " " + str(self.owner.all())
        



